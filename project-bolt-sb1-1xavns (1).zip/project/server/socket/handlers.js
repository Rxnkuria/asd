import { whatsAppService } from '../services/whatsapp.js';

export async function setupWhatsAppEvents(socket) {
  try {
    if (!whatsAppService.isInitialized()) {
      console.log('Setting up WhatsApp events...');
      const client = await whatsAppService.initialize();
      
      client.on('qr', async (qr) => {
        try {
          console.log('New QR Code received');
          const qrCodeDataUrl = await whatsAppService.generateQR(qr);
          socket.emit('qr', qrCodeDataUrl);
        } catch (error) {
          console.error('QR error:', error);
          socket.emit('error', 'Failed to generate QR code');
        }
      });

      client.on('ready', () => {
        socket.emit('ready');
        console.log('WhatsApp client is ready');
      });

      client.on('authenticated', () => {
        socket.emit('authenticated');
        console.log('WhatsApp client is authenticated');
      });

      whatsAppService.on('error', (error) => {
        socket.emit('error', error);
      });

      whatsAppService.on('disconnected', (reason) => {
        socket.emit('disconnected', reason);
      });

      whatsAppService.on('state_change', (state) => {
        socket.emit('state_change', state);
      });

      try {
        console.log('Initializing WhatsApp client...');
        await client.initialize();
      } catch (error) {
        console.error('Client initialization error:', error);
        socket.emit('error', 'Failed to initialize WhatsApp client');
        await whatsAppService.cleanup();
      }
    }
  } catch (error) {
    console.error('Setup error:', error);
    socket.emit('error', 'Failed to initialize WhatsApp');
    await whatsAppService.cleanup();
  }
}