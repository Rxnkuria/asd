import puppeteer from 'puppeteer';
import { puppeteerConfig } from '../config/puppeteer.js';
import { EventEmitter } from 'events';

export class BrowserService extends EventEmitter {
  constructor() {
    super();
    this.browser = null;
    this.page = null;
  }

  async initialize() {
    try {
      this.browser = await puppeteer.launch(puppeteerConfig);
      const context = await this.browser.createIncognitoBrowserContext();
      this.page = await context.newPage();
      
      await this.configurePageSettings();
      await this.setupRequestInterception();
      this.setupMonitoring();
      
      await this.navigateToWhatsApp();
      
      return {
        browser: this.browser,
        page: this.page,
        browserWSEndpoint: this.browser.wsEndpoint()
      };
    } catch (error) {
      console.error('Browser initialization error:', error);
      await this.cleanup();
      throw error;
    }
  }

  async configurePageSettings() {
    await Promise.all([
      this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'),
      this.page.setBypassCSP(true),
      this.page.setDefaultNavigationTimeout(60000),
      this.page.setDefaultTimeout(60000)
    ]);
  }

  async setupRequestInterception() {
    await this.page.setRequestInterception(true);
    this.page.on('request', (request) => {
      const resourceType = request.resourceType();
      if (['image', 'stylesheet', 'font', 'script'].includes(resourceType)) {
        request.continue();
      } else if (resourceType === 'xhr' || resourceType === 'fetch') {
        request.url().includes('web.whatsapp.com') ? request.continue() : request.abort();
      } else {
        request.continue();
      }
    });
  }

  setupMonitoring() {
    this.page.on('error', error => {
      console.error('Page error:', error);
      this.emit('error', 'Page error occurred');
    });

    this.page.on('console', msg => {
      const text = msg.text();
      if (text.includes('error') || text.includes('Error')) {
        console.error('Browser console error:', text);
      }
    });

    this.page.on('pageerror', error => {
      console.error('Page error:', error);
      this.emit('error', 'Page error occurred');
    });

    this.page.on('requestfailed', request => {
      console.error('Failed request:', request.url(), request.failure());
    });
  }

  async navigateToWhatsApp() {
    console.log('Navigating to WhatsApp Web...');
    await this.page.goto('https://web.whatsapp.com', {
      waitUntil: ['networkidle0', 'domcontentloaded'],
      timeout: 60000
    });
    console.log('WhatsApp Web page loaded');
  }

  async cleanup() {
    if (this.page) {
      try {
        await this.page.close();
      } catch (error) {
        console.error('Page cleanup error:', error);
      }
      this.page = null;
    }

    if (this.browser) {
      try {
        await this.browser.close();
      } catch (error) {
        console.error('Browser cleanup error:', error);
      }
      this.browser = null;
    }
  }
}