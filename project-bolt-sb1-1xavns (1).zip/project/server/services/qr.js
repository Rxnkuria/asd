import qrcode from 'qrcode';

export class QRService {
  static async generateQR(qrCode) {
    try {
      return await qrcode.toDataURL(qrCode, {
        errorCorrectionLevel: 'H',
        margin: 1,
        scale: 8,
        width: 256
      });
    } catch (error) {
      console.error('QR generation error:', error);
      throw error;
    }
  }
}