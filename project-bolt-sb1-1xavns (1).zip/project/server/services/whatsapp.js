import { Client, LocalAuth } from 'whatsapp-web.js';
import { EventEmitter } from 'events';
import { BrowserService } from './browser.js';
import { QRService } from './qr.js';

class WhatsAppService extends EventEmitter {
  constructor() {
    super();
    this.client = null;
    this.browserService = new BrowserService();
    this.connectionRetries = 0;
    this.maxRetries = 3;
    this.retryDelay = 5000;
  }

  async initialize() {
    try {
      if (this.connectionRetries >= this.maxRetries) {
        throw new Error('Max connection retries reached');
      }

      console.log('Starting WhatsApp initialization...');
      
      if (this.client) {
        await this.cleanup();
      }

      const browserConfig = await this.browserService.initialize();
      
      this.client = new Client({
        authStrategy: new LocalAuth({ clientId: 'whatsapp-web-client' }),
        puppeteer: browserConfig
      });

      this.setupClientEvents();
      return this.client;

    } catch (error) {
      console.error('WhatsApp initialization error:', error);
      await this.cleanup();
      
      this.connectionRetries++;
      if (this.connectionRetries < this.maxRetries) {
        console.log(`Retrying connection (${this.connectionRetries}/${this.maxRetries})...`);
        await new Promise(resolve => setTimeout(resolve, this.retryDelay));
        return this.initialize();
      }
      
      throw error;
    }
  }

  setupClientEvents() {
    this.client.on('disconnected', async (reason) => {
      console.log('WhatsApp disconnected:', reason);
      this.emit('disconnected', reason);
      await this.cleanup();
    });

    this.client.on('auth_failure', async () => {
      console.error('Authentication failed');
      this.emit('auth_failure');
      await this.cleanup();
    });

    this.client.on('change_state', (state) => {
      console.log('WhatsApp state changed:', state);
      this.emit('state_change', state);
    });

    this.browserService.on('error', (error) => {
      this.emit('error', error);
    });
  }

  async generateQR(qrCode) {
    return QRService.generateQR(qrCode);
  }

  async cleanup() {
    console.log('Cleaning up WhatsApp service...');
    
    if (this.client) {
      try {
        await this.client.destroy();
      } catch (error) {
        console.error('Client cleanup error:', error);
      }
      this.client = null;
    }

    await this.browserService.cleanup();
    this.connectionRetries = 0;
  }

  isInitialized() {
    return this.client !== null;
  }

  async sendMessage(to, message) {
    if (!this.isInitialized()) {
      throw new Error('WhatsApp client not initialized');
    }

    try {
      const chat = await this.client.getChatById(to);
      await chat.sendMessage(message);
      return true;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }
}

export const whatsAppService = new WhatsAppService();