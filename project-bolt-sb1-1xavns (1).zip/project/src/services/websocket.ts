import { io, Socket } from 'socket.io-client';

export interface WebSocketEvents {
  qr: (qr: string) => void;
  authenticated: () => void;
  error: (error: string) => void;
  message: (message: any) => void;
  ready: () => void;
}

class WebSocketService {
  private socket: Socket | null = null;
  private static instance: WebSocketService;
  private reconnectTimer: NodeJS.Timeout | null = null;

  private constructor() {}

  static getInstance(): WebSocketService {
    if (!WebSocketService.instance) {
      WebSocketService.instance = new WebSocketService();
    }
    return WebSocketService.instance;
  }

  connect(): void {
    if (this.socket?.connected) return;

    this.socket = io('http://localhost:3000', {
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 3000,
      timeout: 10000
    });

    this.socket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
      if (!this.reconnectTimer) {
        this.reconnectTimer = setTimeout(() => {
          this.reconnect();
        }, 5000);
      }
    });

    this.socket.on('connect', () => {
      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }
    });
  }

  private reconnect(): void {
    this.disconnect();
    this.connect();
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  on<T extends keyof WebSocketEvents>(event: T, callback: WebSocketEvents[T]): void {
    this.socket?.on(event, callback as (...args: any[]) => void);
  }

  emit<T>(event: string, data?: T): void {
    this.socket?.emit(event, data);
  }

  isConnected(): boolean {
    return this.socket?.connected ?? false;
  }
}

export const wsService = WebSocketService.getInstance();