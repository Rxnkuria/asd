import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Loader2, RefreshCcw } from 'lucide-react';
import { useWhatsAppConnection } from '../hooks/useWhatsAppConnection';

export function WhatsAppQR() {
  const { status, qrCode, error, reconnect } = useWhatsAppConnection();

  if (error) {
    return (
      <div className="text-center p-8 bg-red-50 rounded-lg">
        <p className="text-red-600 mb-4">{error}</p>
        <button
          onClick={reconnect}
          className="flex items-center gap-2 mx-auto px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          <RefreshCcw className="w-4 h-4" />
          <span>Try Again</span>
        </button>
      </div>
    );
  }

  if (status === 'loading') {
    return (
      <div className="flex flex-col items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-green-500" />
        <p className="mt-4 text-gray-600">Connecting to WhatsApp...</p>
      </div>
    );
  }

  if (status === 'connected') {
    return (
      <div className="text-center p-8 bg-green-50 rounded-lg">
        <p className="text-green-600 font-medium">WhatsApp Web Connected!</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-lg shadow-lg">
      <div className="mb-6">
        <QRCodeSVG value={qrCode || 'pending'} size={256} />
      </div>
      <p className="text-gray-600 text-center max-w-sm">
        To use WhatsApp Web, scan the QR code with your phone's WhatsApp app
      </p>
      {status === 'disconnected' && (
        <button
          onClick={reconnect}
          className="mt-4 flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
        >
          <RefreshCcw className="w-4 h-4" />
          <span>Reconnect</span>
        </button>
      )}
    </div>
  );
}