import React from 'react';
import { MessageSquare } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-8 h-8 text-green-500" />
          <h1 className="text-xl font-semibold text-gray-900">WhatsApp Connect</h1>
        </div>
      </div>
    </header>
  );
}