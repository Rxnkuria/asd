import { useState, useEffect } from 'react';
import { wsService } from '../services/websocket';

export type ConnectionStatus = 'disconnected' | 'loading' | 'ready' | 'connected';

export function useWhatsAppConnection() {
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [qrCode, setQrCode] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    wsService.connect();
    setStatus('loading');

    wsService.on('qr', (qr: string) => {
      setQrCode(qr);
      setStatus('ready');
      setError('');
    });

    wsService.on('authenticated', () => {
      setStatus('connected');
      setError('');
    });

    wsService.on('error', (err: string) => {
      setError(err);
      setStatus('disconnected');
    });

    wsService.on('ready', () => {
      setStatus('ready');
      setError('');
    });

    return () => {
      wsService.disconnect();
    };
  }, []);

  const reconnect = () => {
    wsService.disconnect();
    wsService.connect();
    setStatus('loading');
    setError('');
  };

  return {
    status,
    qrCode,
    error,
    reconnect,
    isConnected: wsService.isConnected(),
  };
}