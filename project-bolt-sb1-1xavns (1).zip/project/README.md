# WhatsApp Web Connect

تطبيق يتيح الاتصال بـ WhatsApp Web من خلال واجهة ويب.

## المميزات
- ربط مع WhatsApp Web
- عرض رمز QR للمصادقة
- واجهة مستخدم سهلة الاستخدام
- دعم WebSocket للاتصال المباشر

## المتطلبات
- Node.js >= 18.0.0
- npm أو yarn

## التثبيت

1. استنسخ المستودع:
\`\`\`bash
git clone https://github.com/your-username/whatsapp-web-connect.git
\`\`\`

2. انتقل إلى مجلد المشروع:
\`\`\`bash
cd whatsapp-web-connect
\`\`\`

3. ثبت التبعيات:
\`\`\`bash
npm install
\`\`\`

4. انسخ ملف البيئة النموذجي:
\`\`\`bash
cp .env.example .env
\`\`\`

5. عدل ملف \`.env\` حسب إعداداتك.

## التشغيل

لتشغيل المشروع في بيئة التطوير:
\`\`\`bash
npm run dev
\`\`\`

للبناء للإنتاج:
\`\`\`bash
npm run build
\`\`\`

## الهيكل
\`\`\`
├── src/                # ملفات الواجهة الأمامية
│   ├── components/     # مكونات React
│   ├── hooks/          # React Hooks
│   └── services/       # خدمات
├── server/             # ملفات الخادم
│   ├── config/         # إعدادات
│   ├── services/       # خدمات الخادم
│   └── socket/         # معالجات WebSocket
└── public/            # ملفات ثابتة
\`\`\`

## المساهمة
نرحب بالمساهمات! يرجى قراءة [دليل المساهمة](CONTRIBUTING.md) للمزيد من المعلومات.

## الترخيص
[MIT](LICENSE)